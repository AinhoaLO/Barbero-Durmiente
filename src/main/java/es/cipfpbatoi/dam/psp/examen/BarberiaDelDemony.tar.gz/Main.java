package es.cipfpbatoi.dam.psp.examen;

public class Main {
    public static void main(String[] args) {
        Barberia barberia = new Barberia();
        barberia.abrirBarberia();
    }
}